import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../providers/calendar_provider.dart';
import '../shared/app_nav_drawer.dart';

class StudentCalendarScreen extends ConsumerWidget {
  const StudentCalendarScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final classesAsync = ref.watch(studentCalendarProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Calendar')),
      drawer: const AppNavDrawer(),
      body: classesAsync.when(
        data: (classes) {
          if (classes.isEmpty) {
            return const Center(child: Text('No classes scheduled yet.'));
          }
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: classes.length,
            itemBuilder: (context, i) {
              final c = classes[i];
              return Card(
                child: ListTile(
                  title: Text(c.title),
                  subtitle: Text(
                      '${DateFormat('EEE, MMM d · h:mm a').format(c.dateTime)} (${c.durationMinutes} min)'),
                  trailing: c.zoomLink == null || c.hasEnded
                      ? null
                      : TextButton(
                          onPressed: () =>
                              launchUrl(Uri.parse(c.zoomLink!)),
                          child: const Text('Join'),
                        ),
                ),
              );
            },
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Error: $e')),
      ),
    );
  }
}
